((java.util.function.Supplier<Boolean>)() -> {
    try {
        if (!(${input$entity} instanceof net.minecraft.world.entity.LivingEntity)) return false;
        yesman.epicfight.world.capabilities.entitypatch.player.PlayerPatch<?> _efP = yesman.epicfight.world.capabilities.EpicFightCapabilities.getEntityPatch((net.minecraft.world.entity.LivingEntity)${input$entity}, yesman.epicfight.world.capabilities.entitypatch.player.PlayerPatch.class);
        if (_efP == null) return false;
        yesman.epicfight.world.capabilities.skill.CapabilitySkill _efSC = _efP.getSkillCapability();
        if (_efSC == null) return false;
        net.minecraft.resources.ResourceLocation _efLoc = new net.minecraft.resources.ResourceLocation(${input$skill});
        for (yesman.epicfight.skill.SkillContainer _efCont : _efSC.skillContainers) {
            if (_efCont == null) continue;
            yesman.epicfight.skill.Skill _efSk = _efCont.getSkill();
            if (_efSk == null) continue;
            net.minecraft.resources.ResourceLocation _efSkLoc = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(_efSk instanceof net.minecraft.world.item.Item ? (net.minecraft.world.item.Item)_efSk : null);
            if (_efSkLoc == null) {
                for (java.lang.reflect.Method _efM : _efSk.getClass().getMethods()) {
                    if (_efM.getParameterCount() == 0 && _efM.getReturnType() == net.minecraft.resources.ResourceLocation.class) {
                        try { _efSkLoc = (net.minecraft.resources.ResourceLocation)_efM.invoke(_efSk); break; } catch(Exception _efE2){}
                    }
                }
            }
            if (_efLoc.equals(_efSkLoc)) return true;
        }
        return false;
    } catch (Exception _e) { return false; }
}).get()

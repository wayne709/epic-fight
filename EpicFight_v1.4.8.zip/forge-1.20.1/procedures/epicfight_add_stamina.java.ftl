if (${input$entity} instanceof net.minecraft.world.entity.LivingEntity) {
    yesman.epicfight.world.capabilities.entitypatch.player.PlayerPatch<?> _efPP = yesman.epicfight.world.capabilities.EpicFightCapabilities.getEntityPatch((net.minecraft.world.entity.LivingEntity)${input$entity}, yesman.epicfight.world.capabilities.entitypatch.player.PlayerPatch.class);
    if (_efPP != null) _efPP.setStamina((float)Math.min(_efPP.getStamina() + (${input$amount}), _efPP.getMaxStamina()));
}

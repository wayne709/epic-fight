((java.util.function.Supplier<Boolean>)() -> {
    try {
        if (!(${input$entity} instanceof net.minecraft.world.entity.LivingEntity)) return false;
        yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch<?> _p = yesman.epicfight.world.capabilities.EpicFightCapabilities.getEntityPatch((net.minecraft.world.entity.LivingEntity)${input$entity}, yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch.class);
        if (_p == null) return false;
        @SuppressWarnings("unchecked")
        yesman.epicfight.api.animation.Animator _animator = (yesman.epicfight.api.animation.Animator)(Object)_p.getAnimator();
        if (_animator == null) return false;
        @SuppressWarnings({"unchecked","rawtypes"})
        com.mojang.datafixers.util.Pair _pair = _animator.findFor((Class)Class.forName("yesman.epicfight.api.animation.types.DodgeAnimation"));
        return _pair != null && _pair.getFirst() != null;
    } catch (Exception _e) { return false; }
}).get()

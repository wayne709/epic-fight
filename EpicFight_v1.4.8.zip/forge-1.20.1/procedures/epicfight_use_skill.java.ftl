if (${input$entity} instanceof net.minecraft.world.entity.LivingEntity) {
    try {
        yesman.epicfight.world.capabilities.entitypatch.player.PlayerPatch<?> _efP = yesman.epicfight.world.capabilities.EpicFightCapabilities.getEntityPatch((net.minecraft.world.entity.LivingEntity)${input$entity}, yesman.epicfight.world.capabilities.entitypatch.player.PlayerPatch.class);
        if (_efP != null) {
            yesman.epicfight.world.capabilities.skill.CapabilitySkill _efSC = _efP.getSkillCapability();
            if (_efSC != null) {
                net.minecraft.resources.ResourceLocation _efLoc = new net.minecraft.resources.ResourceLocation(${input$skill});
                for (yesman.epicfight.skill.SkillContainer _efCont : _efSC.skillContainers) {
                    if (_efCont == null) continue;
                    yesman.epicfight.skill.Skill _efSk = _efCont.getSkill();
                    if (_efSk == null) continue;
                    net.minecraft.resources.ResourceLocation _efSkLoc = null;
                    for (java.lang.reflect.Method _efM : _efSk.getClass().getMethods()) {
                        if (_efM.getParameterCount() == 0 && _efM.getReturnType() == net.minecraft.resources.ResourceLocation.class) {
                            try { _efSkLoc = (net.minecraft.resources.ResourceLocation)_efM.invoke(_efSk); break; } catch(Exception _efE2){}
                        }
                    }
                    if (_efLoc.equals(_efSkLoc)) {
                        for (java.lang.reflect.Method _efEM : _efCont.getClass().getMethods()) {
                            if (_efEM.getName().toLowerCase().contains("execute") || _efEM.getName().toLowerCase().contains("activate") || _efEM.getName().toLowerCase().contains("trigger")) {
                                if (_efEM.getParameterCount() == 0) { try { _efEM.invoke(_efCont); } catch(Exception _efE3){} break; }
                            }
                        }
                        break;
                    }
                }
            }
        }
    } catch (Exception _e) {}
}

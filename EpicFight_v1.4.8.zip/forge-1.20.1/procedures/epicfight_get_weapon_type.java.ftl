((java.util.function.Supplier<String>)() -> {
    try {
        if (!(${input$entity} instanceof net.minecraft.world.entity.LivingEntity)) return "fist";
        yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch<?> _p = yesman.epicfight.world.capabilities.EpicFightCapabilities.getEntityPatch((net.minecraft.world.entity.LivingEntity)${input$entity}, yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch.class);
        if (_p == null) return "fist";
        yesman.epicfight.world.capabilities.item.CapabilityItem _cap = _p.getHoldingItemCapability(net.minecraft.world.InteractionHand.MAIN_HAND);
        if (_cap == null) return "fist";
        for (java.lang.reflect.Method _m : _cap.getClass().getMethods()) {
            if (_m.getParameterCount() == 0 && _m.getName().toLowerCase().contains("category")) {
                Object _cat = _m.invoke(_cap);
                if (_cat != null) return _cat.toString().toLowerCase();
            }
        }
        return "fist";
    } catch (Exception _e) { return "fist"; }
}).get()

if (${input$entity} instanceof net.minecraft.world.entity.LivingEntity) {
    yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch<?> _efP = yesman.epicfight.world.capabilities.EpicFightCapabilities.getEntityPatch((net.minecraft.world.entity.LivingEntity)${input$entity}, yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch.class);
    if (_efP != null) {
        try {
            String _efAnimName = (${input$animation}).toUpperCase().replace(":", "_").replace("/", "_");
            java.lang.reflect.Field _efF = yesman.epicfight.gameasset.Animations.class.getField(_efAnimName);
            Object _efAcc = _efF.get(null);
            if (_efAcc instanceof yesman.epicfight.api.asset.AssetAccessor) {
                _efP.playAnimationInstantly((yesman.epicfight.api.asset.AssetAccessor)_efAcc);
            }
        } catch (Exception _efE) {}
    }
}

if (${input$entity} instanceof net.minecraft.world.entity.LivingEntity) {
    yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch<?> _efP = yesman.epicfight.world.capabilities.EpicFightCapabilities.getEntityPatch((net.minecraft.world.entity.LivingEntity)${input$entity}, yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch.class);
    if (_efP != null) _efP.playAnimationInstantly(yesman.epicfight.gameasset.Animations.BIPED_IDLE);
}

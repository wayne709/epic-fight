((java.util.function.Supplier<Boolean>)() -> {
    try {
        if (!(${input$entity} instanceof net.minecraft.world.entity.LivingEntity)) return false;
        yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch<?> _p = yesman.epicfight.world.capabilities.EpicFightCapabilities.getEntityPatch((net.minecraft.world.entity.LivingEntity)${input$entity}, yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch.class);
        if (_p == null) return false;
        yesman.epicfight.world.capabilities.item.CapabilityItem _cap = _p.getHoldingItemCapability(net.minecraft.world.InteractionHand.MAIN_HAND);
        if (_cap == null) return "${field$WEAPON_TYPE}".equals("fist");
        String _cat = null;
        for (java.lang.reflect.Method _m : _cap.getClass().getMethods()) {
            if (_m.getParameterCount() == 0 && _m.getName().toLowerCase().contains("category")) {
                Object _c = _m.invoke(_cap);
                if (_c != null) { _cat = _c.toString().toLowerCase(); break; }
            }
        }
        if (_cat == null) return "${field$WEAPON_TYPE}".equals("fist");
        return _cat.contains("${field$WEAPON_TYPE}");
    } catch (Exception _e) { return false; }
}).get()

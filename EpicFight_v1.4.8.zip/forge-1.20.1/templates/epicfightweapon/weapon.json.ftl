{
  "type": "epicfight:weapon",
  "attributes": {
    "common": {
      "armor_negation": ${data.armorNegation},
      "impact": ${data.impact},
      "max_strikes": ${data.maxStrikes},
      "damage_bonus": ${data.damageBonus},
      "speed_bonus": ${data.speedBonus}
    }
  },
  "category": "${data.weaponCategory}",
  "style": "one_hand",
  "swing_sound": "${data.swingSound}",
  "hit_sound": "${data.hitSound}"
}
